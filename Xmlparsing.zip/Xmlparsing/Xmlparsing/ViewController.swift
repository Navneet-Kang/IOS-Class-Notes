//
//  ViewController.swift
//  Xmlparsing
//
//  Created by Greens on 10/9/20.
//  Copyright © 2020 Greens. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,XMLParserDelegate {
    struct Book {
        var bookTitle: String
        var bookAuthor: String
    }
    var books: [Book] = []
    var elementName1 : String = ""
    var bookTitle1 : String = ""
    var bookAuthor1 = String()
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellTest", for: indexPath)
        let book1 = books[indexPath.row]
        //  print(book1)
        cell.textLabel?.text = book1.bookTitle
        cell.detailTextLabel?.text = book1.bookAuthor
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let path = Bundle.main.url(forResource: "books", withExtension: "xml") {
            if let parser = XMLParser(contentsOf: path) {
                parser.delegate = self
                parser.parse()
            }
        }
        // Do any additional setup after loading the view.
        
    }
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        
        if elementName == "book" {
            bookTitle1 = ""
            bookAuthor1 = ""
        }
        self.elementName1 = elementName
        //print(bookAuthor1)
        
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        let data = string.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        if (!data.isEmpty){
            if self.elementName1 == "title" {
                bookTitle1 += data
            }
            else if self.elementName1 == "author" {
                bookAuthor1 += data
            }
        }
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?){
    if elementName == "book" {
        let book2 = Book(bookTitle: bookTitle1, bookAuthor: bookAuthor1)
        //print(book)
        books.append(book2)
    }
    }
}

