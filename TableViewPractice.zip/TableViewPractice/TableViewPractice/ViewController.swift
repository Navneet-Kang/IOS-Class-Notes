//
//  ViewController.swift
//  TableViewPractice
//
//  Created by user165323 on 11/29/20.
//  Copyright © 2020 navneet. All rights reserved.
//

import UIKit



class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    let titleData = ["Dawn of Planent Of Apes" ,"District 9" ,"Transformers Age" ,"X-Men Days Of Future Past","Machitest"]
    let releaseYearData = ["2014","2009","2014","2014","2004"]
    let ratingData=["8.3","8.0" ,"6.3" ,"8.4" ,"7.8"]
    let genreData = ["Action-Drama-Sci","Action-Sci-Fi","Action-Adventure","Action-Thriller","Drama-Thriller"]
    let images = [#imageLiteral(resourceName: "movies"),#imageLiteral(resourceName: "movies"),#imageLiteral(resourceName: "movies"),#imageLiteral(resourceName: "movies"),
                  #imageLiteral(resourceName: "movies")]
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleData.count
    }	
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       var cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyTableViewCell
        cell.title?.text=titleData[indexPath.row]
        cell.releaseYear?.text=releaseYearData[indexPath.row]
        cell.genre?.text=genreData[indexPath.row]
        cell.rating?.text=ratingData[indexPath.row]
        cell.imageView?.image=images[indexPath.row]
        return cell
        
    }
    
 

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
   


}

