//
//  MyTableViewCell.swift
//  TableViewPractice
//
//  Created by user165323 on 11/29/20.
//  Copyright © 2020 navneet. All rights reserved.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    @IBOutlet var title:UILabel?
     @IBOutlet var releaseYear:UILabel?
     @IBOutlet var rating:UILabel?
     @IBOutlet var genre:UILabel?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
