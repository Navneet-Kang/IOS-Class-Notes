//
//  cellTableViewCell.swift
//  new0507
//
//  Created by Green on 07/05/18.
//  Copyright © 2018 Greens. All rights reserved.
//

import UIKit

class cellTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
