//
//  ViewController.swift
//  jsoncoredata2
//
//  Created by Greens on 06/11/20.
//  Copyright © 2020 greens. All rights reserved.
//

import UIKit
import Kingfisher
struct Root: Codable {
    var title : String?
    var image : String?
    var rating : Float?
    var releaseYear : Int?
    var genre : [String]?
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var tabView: UITableView!
    var structVar = [Root]()
//    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let link = "https://api.androidhive.info/json/movies.json"
    
 
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return structVar.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellTest", for: indexPath) as! TableViewCell
        cell.titleLabel.text = structVar[indexPath.row].title!
        cell.titleLabel.textColor = .yellow
        cell.titleLabel.textAlignment = .center
        cell.releaseLabel.text = String(structVar[indexPath.row].releaseYear!)
        cell.releaseLabel.textColor = .green
        cell.ratingLabel.text = String(structVar[indexPath.row].rating!)
        cell.ratingLabel.textColor = .green
        cell.genreLabel.text = structVar[indexPath.row].genre!.joined(separator: "  ")
        cell.genreLabel.textColor = .green
        let img = structVar[indexPath.row].image!
        let url = URL(string: img)
        cell.imgView.kf.setImage(with: url)
        cell.imgView.layer.cornerRadius = 15.0
        cell.imgView.layer.borderWidth = 3
        cell.imgView.layer.borderColor = .init(srgbRed: 2.8, green: 3.1, blue: 2.1, alpha: 3.1)
      
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
            
            guard let url = URL(string: link) else {return}
            let task = URLSession.shared.dataTask(with: url) {(data,response,error)in
                guard error == nil else {return}
                guard let dat = data else {return}
                do{
                    self.structVar = try JSONDecoder().decode([Root].self,from:dat)
                
                DispatchQueue.main.async {
                    self.tabView.reloadData()
                }
                }
                catch {
                    print(error)
                }
        }
            task.resume()
        
        }
            
        // Do any additional setup after loading the view.
    }




